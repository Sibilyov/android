package com.example.toast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.button);
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        // Создание Toast сообщения
        Toast toast = new Toast(getApplicationContext());
        // Позиционирование сообщения
        toast.setGravity(Gravity.CENTER, 0, 0);
        // Определение продолжительности
        toast.setDuration(Toast.LENGTH_LONG);
        // Создание View из контента файла toast.xml:
        LayoutInflater inflater = getLayoutInflater();
        View vw = inflater.inflate(R.layout.toast, null);
        // Определение View компонента
        toast.setView(vw);
        // Представление сообщения
        toast.show();
    }
}